﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;

namespace Interfaces
{
    public interface IPatientRepo
    {
        bool InsertPatient(Patient p);
        bool DeletePatient(Patient p);
        bool UpdatePatient(Patient p);
        Patient GetPatient(string query);
        List<Patient> GetPatientList(string query);
    }
}
