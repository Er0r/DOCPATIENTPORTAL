﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;

namespace Interfaces
{
    public interface IAdminRepo
    {
        bool InsertAdmin(Admin a);
        bool DeleteAdmin(Admin a);
        bool UpdateAdmin(Admin a);
        Admin GetAdmin(string query);
    }
}
