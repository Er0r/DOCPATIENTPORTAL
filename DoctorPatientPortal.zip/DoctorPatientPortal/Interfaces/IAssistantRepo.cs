﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;

namespace Interfaces
{
    public interface IAssistantRepo
    {
        bool InsertAssistant(Assistant a);
        bool DeleteAssistant(Assistant a);
        bool UpdateAssistant(Assistant a);
        Assistant GetAssistant(string query);
        List<Assistant> GetAssistantList(string query);
    }
}
