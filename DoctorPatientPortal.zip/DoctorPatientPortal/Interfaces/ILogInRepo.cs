﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;

namespace Interfaces
{
    public interface ILogInRepo
    {
        bool InsertUser(LogIn l);
        bool DeleteUser(LogIn l);
        bool UpdateUser(LogIn l);
        LogIn GetUser(string query);
    }
}
