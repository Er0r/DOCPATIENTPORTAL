﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Entity;

namespace Interfaces
{
    public interface ISlotRepo
    {
        bool InsertSlot(Slot s);
        bool DeleteSlot(Slot s);
        bool UpdateSlot(Slot s);
        Slot GetSlot(string query);
        List<Slot> GetSlotList(string query);
    }
}
