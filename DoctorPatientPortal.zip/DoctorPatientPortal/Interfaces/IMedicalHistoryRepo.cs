﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;

namespace Interfaces
{
    public interface IMedicalHistoryRepo
    {
        bool InsertMedicalHistory(MedicalHistory m);
        bool DeleteMedicalHistory(MedicalHistory m);
        List<MedicalHistory> GetMedicalHistoryList(string query);
    }
}
