﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;

namespace Interfaces
{
    public interface IDrugRepo
    {
        bool InsertDrug(Drug d);
        bool DeleteDrug(Drug d);
        bool UpdateDrug(Drug d);
        Drug GetDrug(string query);
        List<Drug> GetDrugList(string query);
    }
}
