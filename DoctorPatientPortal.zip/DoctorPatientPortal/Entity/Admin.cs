﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entity
{
    public class Admin
    {
        private string id;

        public string Id
        {
            get { return id; }
            set { id = value; }
        }

        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string salary;

        public string Salary
        {
            get { return salary; }
            set { salary = value; }
        }

        private string shift;

        public string Shift
        {
            get { return shift; }
            set { shift = value; }
        }

        

    }
}
