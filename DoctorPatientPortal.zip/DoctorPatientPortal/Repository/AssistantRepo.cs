﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Interfaces;
using Entity;
using System.Data.SqlClient;

namespace Repository
{
    public class AssistantRepo:IAssistantRepo
    {
        DatabaseConnectionClass dbc;

        public AssistantRepo()
        {
            dbc = new DatabaseConnectionClass();
        }

        public bool InsertAssistant(Assistant r)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "INSERT INTO Assistants VALUES(" + r.Id + ",'" + r.Name + "'," + r.Salary + ",'" + r.Shift + "')";
                int i = dbc.ExecuteSQL(query);
                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public bool DeleteAssistant(Assistant r)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "DELETE Assistants WHERE Id=" + r.Id;
                int i = dbc.ExecuteSQL(query);
                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public bool UpdateAssistant(Assistant r)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "UPDATE Assistants SET NAME='" + r.Name + "',Salary=" + r.Salary + ",Shift='" + r.Shift + "' WHERE Id=" + r.Id;
                int i = dbc.ExecuteSQL(query);
                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public Assistant GetAssistant(string query)
        {
            Assistant r = null;
            try
            {
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    r = new Assistant();
                    r.Id = data["Id"].ToString();
                    r.Name = data["Name"].ToString();
                    r.Salary = Convert.ToDouble(data["Salary"]);
                    r.Shift = data["Shift"].ToString();
                }
                dbc.CloseConnection();
                return r;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return r;
            }
        }

        public List<Assistant> GetAssistantList(string query)
        {
            List<Assistant> list = new List<Assistant>();
            try
            {
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    Assistant r = new Assistant();
                    r.Id = data["Id"].ToString();
                    r.Name = data["Name"].ToString();
                    r.Salary = Convert.ToDouble(data["Salary"]);
                    r.Shift = data["Shift"].ToString();
                    list.Add(r);
                }
                dbc.CloseConnection();
                return list;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return list;
            }
        }
    }
}
