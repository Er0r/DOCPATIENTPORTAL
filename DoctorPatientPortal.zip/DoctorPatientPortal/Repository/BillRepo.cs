﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;
using Interfaces;
using System.Data.SqlClient;

namespace Repository
{
    public class BillRepo:IBillRepo
    {
        DatabaseConnectionClass dbc;

        public BillRepo()
        {
            dbc = new DatabaseConnectionClass();
        }

        public bool InsertBill(Bill b)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "INSERT INTO Bills VALUES('" + b.PatientId + "','" + b.SlotId + "','" + b.Fee + "','" + b.BedId + "','" + b.Rent + "','" + b.RentingDate + "','" + b.MedName + "','" + b.Price + "','" + b.Quantity + "')";
                int i = dbc.ExecuteSQL(query);
                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public bool DeleteBill(Bill b)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "DELETE FROM Bills WHERE PatientId='"+b.PatientId+"'";
                int i = dbc.ExecuteSQL(query);
                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public List<Bill> GetBillList(string query)
        {
            List<Bill> list = new List<Bill>();
            try
            {
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    Bill b = new Bill();
                    b.PatientId = data[0].ToString();
                    b.SlotId = data[1].ToString();
                    b.Fee = data[2].ToString();
                    b.BedId = data[3].ToString();
                    b.Rent = data[4].ToString();
                    b.RentingDate = data[5].ToString();
                    b.MedName = data[6].ToString();
                    b.Price = data[7].ToString();
                    b.Quantity = data[8].ToString();
                    list.Add(b);
                }
                dbc.CloseConnection();
                return list;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return list;
            }
        }


        public bool DeleteBill(Bill b, string sId)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "DELETE FROM Bills WHERE PatientId='" + b.PatientId + "' AND SlotId='"+sId+"'";
                int i = dbc.ExecuteSQL(query);
                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }
    }
}
