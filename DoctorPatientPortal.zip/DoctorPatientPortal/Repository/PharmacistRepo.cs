﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;
using Interfaces;
using System.Data.SqlClient;

namespace Repository
{
    public class PharmacistRepo:IPharmacistRepo
    {
        DatabaseConnectionClass dbc;

        public PharmacistRepo()
        {
            dbc = new DatabaseConnectionClass();
        }

        public bool InsertPharmacist(Pharmacist r)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "INSERT INTO Pharmacists VALUES(" + r.Id + ",'" + r.Name + "'," + r.Salary + ",'" + r.Shift + "')";
                int i = dbc.ExecuteSQL(query);
                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public bool DeletePharmacist(Pharmacist r)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "DELETE FROM Pharmacists WHERE Id=" + r.Id;
                int i = dbc.ExecuteSQL(query);
                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public bool UpdatePharmacist(Pharmacist r)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "UPDATE Pharmacists SET NAME='" + r.Name + "',Salary=" + r.Salary + ",Shift='" + r.Shift + "' WHERE Id=" + r.Id;
                int i = dbc.ExecuteSQL(query);
                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public Pharmacist GetPharmacist(string query)
        {
            Pharmacist r = null;
            try
            {
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    r = new Pharmacist();
                    r.Id = data["Id"].ToString();
                    r.Name = data["Name"].ToString();
                    r.Salary = Convert.ToDouble(data["Salary"]);
                    r.Shift = data["Shift"].ToString();
                }
                dbc.CloseConnection();
                return r;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return r;
            }
        }

        public List<Pharmacist> GetPharmacistList(string query)
        {
            List<Pharmacist> list = new List<Pharmacist>();
            try
            {
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    Pharmacist r = new Pharmacist();
                    r.Id = data["Id"].ToString();
                    r.Name = data["Name"].ToString();
                    r.Salary = Convert.ToDouble(data["Salary"]);
                    r.Shift = data["Shift"].ToString();
                    list.Add(r);
                }
                dbc.CloseConnection();
                return list;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return list;
            }
        }
    }
}
