﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;
using Interfaces;
using System.Data.SqlClient;

namespace Repository
{
    public class MedPurchaseHistoryRepo:IMedPurchaseHistoryRepo
    {
        DatabaseConnectionClass dbc;
        public MedPurchaseHistoryRepo()
        {
            dbc = new DatabaseConnectionClass();
        }

        public bool InsertMedPurchaseHistory(MedPurchaseHistory m)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "INSERT INTO MedPurchaseHistories VALUES('" + m.PatientId + "','" + m.EntryDate + "','" + m.DrugName + "','" + m.PurchaseDate + "','" + m.Quantity + "','" + m.Cost + "')";
                int i = dbc.ExecuteSQL(query);
                if (i != 0)
                {
                    dbc.CloseConnection();
                    return true;
                }
                else
                {
                    dbc.CloseConnection();
                    return false;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public List<MedPurchaseHistory> GetMedPurchaseHistoryList(string query)
        {
            List<MedPurchaseHistory> list = new List<MedPurchaseHistory>();
            try
            {
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    MedPurchaseHistory m = new MedPurchaseHistory();
                    m.PatientId = data[0].ToString();
                    m.EntryDate = data[1].ToString();
                    m.DrugName = data[2].ToString();
                    m.PurchaseDate = data[3].ToString();
                    m.Quantity = data[4].ToString();
                    m.Cost = data[5].ToString();
                    list.Add(m);
                }
                dbc.CloseConnection();
                return list;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return list;
            }
        }
    }
}
