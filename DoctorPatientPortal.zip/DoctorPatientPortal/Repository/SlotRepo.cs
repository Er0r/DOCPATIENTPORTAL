﻿using Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;
using System.Data.SqlClient;

namespace Repository
{
    public class SlotRepo:ISlotRepo
    {
        DatabaseConnectionClass dbc;
        List<Slot> slotList;

        public SlotRepo()
        {
            this.dbc = new DatabaseConnectionClass();
            
        }

        public bool InsertSlot(Slot s)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "INSERT INTO Slots(DoctorId,SlotTime,SlotDate,Price,Availability) VALUES('" + s.DoctorId + "','" + s.SlotTime + "','" + s.SlotDate + "'," + s.Price + ",'" + s.Availability + "')";
                int i = dbc.ExecuteSQL(query);
                dbc.CloseConnection();
                if (i == 0) return false;
                return true;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public bool DeleteSlot(Slot s)
        {
            throw new NotImplementedException();
        }

        public bool UpdateSlot(Slot s)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "UPDATE Slots SET DoctorId='"+s.DoctorId+"', PatientId='"+s.PatientId+"',SlotTime='"+s.SlotTime+"',SlotDate='"+s.SlotDate+"',Price="+s.Price+",Availability='"+s.Availability+"' WHERE Id="+s.Id;
                int i = dbc.ExecuteSQL(query);
                dbc.CloseConnection();
                if (i == 0) return false;
                return true;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public Slot GetSlot(string query)
        {
            Slot s=null;
            try
            {
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    s = new Slot();
                    s.Id = data["Id"].ToString();
                    s.PatientId = data["PatientId"].ToString();
                    s.DoctorId = data["DoctorId"].ToString();
                    s.Price = Convert.ToDouble(data["Price"]);
                    s.SlotDate = data["SlotDate"].ToString();
                    s.SlotTime = data["SlotTime"].ToString();
                    s.Availability = data["Availability"].ToString();

                    slotList.Add(s);
                }
                dbc.CloseConnection();
                return s;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return s;
            }
        }

        public List<Slot> GetSlotList(string query)
        {
            try
            {
                slotList = new List<Slot>();
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    Slot s = new Slot();
                    s.Id = data["Id"].ToString();
                    s.PatientId = data["PatientId"].ToString();
                    s.DoctorId = data["DoctorId"].ToString();
                    s.Price = Convert.ToDouble(data["Price"]);
                    s.SlotDate = data["SlotDate"].ToString();
                    s.SlotTime = data["SlotTime"].ToString();
                    s.Availability = data["Availability"].ToString();
                    slotList.Add(s);
                }
                dbc.CloseConnection();
                return slotList;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return slotList;
            }

        }
    }
}
