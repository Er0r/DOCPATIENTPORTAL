﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Interfaces;
using Entity;
using System.Data.SqlClient;


namespace Repository
{
    public class LogInRepo:ILogInRepo
    {
        DatabaseConnectionClass dbc;

        public LogInRepo()
        {
            dbc = new DatabaseConnectionClass();
        }

        public bool InsertUser(LogIn l)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "INSERT INTO LogIns VALUES(" + l.Id + ",'" + l.Password + "'," + l.Role + ")";
                int i = dbc.ExecuteSQL(query);

                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public bool DeleteUser(LogIn l)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "DELETE FROM LogIns WHERE Id=" + l.Id;
                int i = dbc.ExecuteSQL(query);
                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public bool UpdateUser(LogIn l)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "UPDATE LogIns SET Password='"+l.Password+"' WHERE Id=" + l.Id;
                int i = dbc.ExecuteSQL(query);
                if (i == 0)
                {
                    dbc.CloseConnection();
                    return false;
                }
                else
                {
                    dbc.CloseConnection();
                    return true;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public LogIn GetUser(string query)
        {
            LogIn l = null; ;
            try
            {
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    l = new LogIn();
                    l.Id = data["Id"].ToString();
                    l.Password = data["Password"].ToString();
                    l.Role=Convert.ToInt32(data["Role"]);
                }
                dbc.CloseConnection();
                return l;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                Console.WriteLine(ex.Message);
                return l;
            }
        }
    }
}
