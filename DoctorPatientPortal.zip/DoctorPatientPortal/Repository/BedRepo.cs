﻿using Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;
using System.Data.SqlClient;

namespace Repository
{
    public class BedRepo:IBedRepo
    {
        DatabaseConnectionClass dbc;
        List<Bed> bedList;

        public BedRepo()
        {
            dbc = new DatabaseConnectionClass();
        }

        public bool InsertBed(Bed b)
        {
            throw new NotImplementedException();
        }

        public bool DeleteBed(Bed b)
        {
            throw new NotImplementedException();
        }

        public bool UpdateBed(Bed b)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "UPDATE Beds SET BedNo="+b.BedNo+",RoomNo="+b.RoomNo+",Rent="+b.Rent+",Availability='"+b.Availability+"' WHERE Id="+b.Id;
                dbc.ExecuteSQL(query);

                dbc.CloseConnection();
                return true;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public Bed GetBed(string query)
        {
            Bed b = null;

            try
            {  
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    b = new Bed();
                    b.Id = data["Id"].ToString();
                    b.BedNo = data["BedNo"].ToString();
                    b.RoomNo = data["RoomNo"].ToString();
                    b.Rent = Convert.ToDouble(data["Rent"]);
                    b.Availability = data["Availability"].ToString();
                }
                dbc.CloseConnection();
                return b;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return b;
            }
        }

        public List<Bed> GetBedList(string query)
        {
            try
            {
                bedList = new List<Bed>();
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    Bed b = new Bed();
                    b.Id = data["Id"].ToString();
                    b.BedNo = data["BedNo"].ToString();
                    b.RoomNo = data["RoomNo"].ToString();
                    b.Rent = Convert.ToDouble(data["Rent"]);
                    b.Availability = data["Availability"].ToString();

                    bedList.Add(b);
                }
                dbc.CloseConnection();
                return bedList;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return bedList;
            }
        }
    }
}
