﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entity;
using Interfaces;
using System.Data.SqlClient;

namespace Repository
{
    public class DrugRepo:IDrugRepo
    {
        DatabaseConnectionClass dbc;

        public DrugRepo()
        {
            dbc = new DatabaseConnectionClass();
        }

        public bool InsertDrug(Drug d)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "INSERT INTO Drugs VALUES('" + d.Name + "','" + d.ProducerComapany + "'," + d.Price + "," + d.AvailableQuantity + ")";
                int i = dbc.ExecuteSQL(query);
                if (i != 0)
                {
                    dbc.CloseConnection();
                    return true;
                }
                else
                {
                    dbc.CloseConnection();
                    return false;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public bool DeleteDrug(Drug d)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "DELETE FROM Drugs WHERE Name='"+d.Name+"'";
                int i = dbc.ExecuteSQL(query);
                if (i != 0)
                {
                    dbc.CloseConnection();
                    return true;
                }
                else
                {
                    dbc.CloseConnection();
                    return false;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public bool UpdateDrug(Drug d)
        {
            try
            {
                dbc.ConnectWithDB();
                string query = "UPDATE Drugs SET ProducerCompany='" + d.ProducerComapany + "',Price=" + d.Price + ",AvailableQuantity=" + d.AvailableQuantity + " WHERE Name='"+d.Name+"'";
                int i = dbc.ExecuteSQL(query);
                if (i != 0)
                {
                    dbc.CloseConnection();
                    return true;
                }
                else
                {
                    dbc.CloseConnection();
                    return false;
                }
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return false;
            }
        }

        public Drug GetDrug(string query)
        {
            Drug d = null;
            try
            {
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    d = new Drug();
                    d.Name = data["Name"].ToString();
                    d.Price = Convert.ToDouble(data["Price"]);
                    d.ProducerComapany = data["ProducerCompany"].ToString();
                    d.AvailableQuantity = Convert.ToDouble(data["AvailableQuantity"]);
                }
                dbc.CloseConnection();
                return d;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return d;
            }
        }

        public List<Drug> GetDrugList(string query)
        {
            List<Drug> list = new List<Drug>();
            try
            {
                dbc.ConnectWithDB();
                SqlDataReader data = dbc.GetData(query);
                while (data.Read())
                {
                    Drug d = new Drug();
                    d.Name = data["Name"].ToString();
                    d.Price = Convert.ToDouble(data["Price"]);
                    d.ProducerComapany = data["ProducerCompany"].ToString();
                    d.AvailableQuantity = Convert.ToDouble(data["AvailableQuantity"]);
                    list.Add(d);
                }
                dbc.CloseConnection();
                return list;
            }
            catch (Exception ex)
            {
                dbc.CloseConnection();
                return list;
            }
        }
    }
}
