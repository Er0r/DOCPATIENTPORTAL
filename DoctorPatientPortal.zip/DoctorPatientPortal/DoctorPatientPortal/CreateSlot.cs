﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repository;
using Entity;

namespace Forms
{
    public partial class CreateSlot : UserControl
    {
        Form f;
        Button mngBtn, mhBtn, crtSlot;
        string date;
        SelectCreateSlotDate selectCreateSlotDate;
        Doctor d;

        List<CheckBox> list;

        public CreateSlot(Doctor d,SelectCreateSlotDate selectCreateSlotDate, Form f,Button mngBtn,Button mhBtn,Button crtSlot,string date)
        {
            InitializeComponent();
            this.f = f;
            this.mngBtn = mngBtn;
            this.mhBtn = mhBtn;
            this.crtSlot = crtSlot;
            this.date = date;
            this.label2.Text = this.label2.Text + this.date;
            this.selectCreateSlotDate = selectCreateSlotDate;
            list = new List<CheckBox>();

            list.Add(checkBox1);
            list.Add(checkBox2);
            list.Add(checkBox3);
            list.Add(checkBox4);
            list.Add(checkBox5);
            list.Add(checkBox6);
            list.Add(checkBox7);
            list.Add(checkBox8);
            list.Add(checkBox9);
            list.Add(checkBox10);
            list.Add(checkBox11);
            list.Add(checkBox12);
            list.Add(checkBox13);
            list.Add(checkBox14);
            list.Add(checkBox15);
            list.Add(checkBox16);
            list.Add(checkBox17);
            list.Add(checkBox18);
            list.Add(checkBox19);
            list.Add(checkBox20);
            list.Add(checkBox21);
            list.Add(checkBox22);
            list.Add(checkBox23);
            list.Add(checkBox24);
            list.Add(checkBox25);
            this.d = d;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.mngBtn.Enabled = true;
            this.mhBtn.Enabled = true;

            f.Controls.Add(selectCreateSlotDate);

            f.Controls.Remove(this);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SlotRepo sr = new SlotRepo();
            bool inserted=false;

            for (int i = 0; i < list.Count; i++)
            {
                if (list.ElementAt(i).Checked)
                {
                    Slot s = new Slot();
                    s.DoctorId = d.Id;
                    s.SlotDate = date;
                    s.SlotTime = list.ElementAt(i).Text;
                    s.Availability = "true";
                    if (s.SlotTime.Equals("3.00 pm-3.30 pm") || s.SlotTime.Equals("3.30 pm-4.00 pm") || s.SlotTime.Equals("4.00 pm-4.30 pm") || s.SlotTime.Equals("4.30 pm-5.00 pm"))
                    {
                        s.Price = 500;
                    }
                    else
                        s.Price = 400;

                    inserted = sr.InsertSlot(s);
                }
            }
            if (inserted)
            {
                MessageBox.Show("All Slots inserted successfully.");
            }
            else
            {
                MessageBox.Show("All Slots couldn't be inserted successfully.");
            }
            button4_Click(sender, e);
        }

        private void selectAllBtn_Click(object sender, EventArgs e)
        {
            foreach (CheckBox cb in list)
            {
                cb.Checked = true;
            }
        }

        private void unselectAllBtn_Click(object sender, EventArgs e)
        {
            foreach (CheckBox cb in list)
            {
                cb.Checked = false;
            }
        }
    }
}
