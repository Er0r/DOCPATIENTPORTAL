﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using Repository;

namespace Forms
{
    public partial class AvailUnavailSlot : Form
    {
        Form f;
        string sId;
        Slot s;
        SlotRepo sr;
        UserControl u;

        public AvailUnavailSlot(Form f,UserControl u,string sId )
        {
            InitializeComponent();
            this.f = f;
            this.sId = sId;
            this.u = u;

            this.sr = new SlotRepo();
            this.s=sr.GetSlot("SELECT * FROM Slots WHERE ID="+sId);

            this.slotIdLabel.Text = s.Id;
            this.patientIdLabel.Text = s.PatientId;
            this.slotDateLabel.Text = s.SlotDate;
            this.slotTimeLabel.Text = s.SlotTime;
            this.availabilityLabel.Text = s.Availability;

            if (s.Availability.Equals("true"))
            {
                this.makeUnavailableBtn.Text = "Make Unavailable";
            }
            else
            {
                this.makeUnavailableBtn.Text = "Make Available";
            }

            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        private void AvailUnavailSlot_FormClosed(object sender, FormClosedEventArgs e)
        {
            f.Enabled = true;
            u.Enabled = true;
            this.Dispose();
        }

        private void makeUnavailableBtn_Click(object sender, EventArgs e)
        {
            if (makeUnavailableBtn.Text.Equals("Make Available"))
            {
                if (s.PatientId.Equals("0"))
                {
                    s.Availability = "true";
                    makeUnavailableBtn.Text = "Make Unavailable";
                }
                else
                {
                    MessageBox.Show("Cannot Modify this Slot");
                }
            }
            else
            {
                s.Availability = "false";
                makeUnavailableBtn.Text = "Make Available";
            }
            if(sr.UpdateSlot(s))
                this.availabilityLabel.Text = s.Availability;
        }
    }
}
