﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;

namespace Forms
{
    public partial class DoctorProfile : Form
    {
        Doctor d;
        Form f;
        Entity.LogIn l;

        public DoctorProfile(Doctor d,Form f,Entity.LogIn l)
        {
            InitializeComponent();
            this.d = d;
            this.f = f;

            this.l = l;

            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            idLabel.Text = d.Id;
            nameLabel.Text = d.Name;
            roomNoLabel.Text = d.RoomNo;
            expLabel.Text = d.Expertise;
        }

        private void chngPassBtn_Click(object sender, EventArgs e)
        {
            ChangePassword Cp = new ChangePassword(l);
            Cp.Visible = true;
        }

        private void okBtn_Click(object sender, EventArgs e)
        {
            f.Enabled = true;
            this.Dispose();
        }

        private void DoctorProfile_FormClosed(object sender, FormClosedEventArgs e)
        {
            f.Enabled = true;
            this.Dispose();
        }
    }
}
