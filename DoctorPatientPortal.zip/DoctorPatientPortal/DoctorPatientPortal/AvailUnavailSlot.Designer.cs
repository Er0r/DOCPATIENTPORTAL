﻿namespace Forms
{
    partial class AvailUnavailSlot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.slotIdLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.patientIdLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.slotDateLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.slotTimeLabel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.availabilityLabel = new System.Windows.Forms.Label();
            this.makeUnavailableBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Slot ID:";
            // 
            // slotIdLabel
            // 
            this.slotIdLabel.AutoSize = true;
            this.slotIdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slotIdLabel.Location = new System.Drawing.Point(129, 33);
            this.slotIdLabel.Name = "slotIdLabel";
            this.slotIdLabel.Size = new System.Drawing.Size(64, 25);
            this.slotIdLabel.TabIndex = 0;
            this.slotIdLabel.Text = "label1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "Patient ID:";
            // 
            // patientIdLabel
            // 
            this.patientIdLabel.AutoSize = true;
            this.patientIdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patientIdLabel.Location = new System.Drawing.Point(129, 87);
            this.patientIdLabel.Name = "patientIdLabel";
            this.patientIdLabel.Size = new System.Drawing.Size(64, 25);
            this.patientIdLabel.TabIndex = 0;
            this.patientIdLabel.Text = "label1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 25);
            this.label5.TabIndex = 0;
            this.label5.Text = "Slot Date:";
            // 
            // slotDateLabel
            // 
            this.slotDateLabel.AutoSize = true;
            this.slotDateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slotDateLabel.Location = new System.Drawing.Point(129, 148);
            this.slotDateLabel.Name = "slotDateLabel";
            this.slotDateLabel.Size = new System.Drawing.Size(64, 25);
            this.slotDateLabel.TabIndex = 0;
            this.slotDateLabel.Text = "label1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 211);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 25);
            this.label7.TabIndex = 0;
            this.label7.Text = "Slot Time:";
            // 
            // slotTimeLabel
            // 
            this.slotTimeLabel.AutoSize = true;
            this.slotTimeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slotTimeLabel.Location = new System.Drawing.Point(129, 211);
            this.slotTimeLabel.Name = "slotTimeLabel";
            this.slotTimeLabel.Size = new System.Drawing.Size(64, 25);
            this.slotTimeLabel.TabIndex = 0;
            this.slotTimeLabel.Text = "label1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 272);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 25);
            this.label9.TabIndex = 0;
            this.label9.Text = "Availability:";
            // 
            // availabilityLabel
            // 
            this.availabilityLabel.AutoSize = true;
            this.availabilityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.availabilityLabel.Location = new System.Drawing.Point(129, 272);
            this.availabilityLabel.Name = "availabilityLabel";
            this.availabilityLabel.Size = new System.Drawing.Size(64, 25);
            this.availabilityLabel.TabIndex = 0;
            this.availabilityLabel.Text = "label1";
            // 
            // makeUnavailableBtn
            // 
            this.makeUnavailableBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.makeUnavailableBtn.Location = new System.Drawing.Point(297, 332);
            this.makeUnavailableBtn.Name = "makeUnavailableBtn";
            this.makeUnavailableBtn.Size = new System.Drawing.Size(134, 66);
            this.makeUnavailableBtn.TabIndex = 1;
            this.makeUnavailableBtn.Text = "Make Unavailable";
            this.makeUnavailableBtn.UseVisualStyleBackColor = true;
            this.makeUnavailableBtn.Click += new System.EventHandler(this.makeUnavailableBtn_Click);
            // 
            // AvailUnavailSlot
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 410);
            this.Controls.Add(this.makeUnavailableBtn);
            this.Controls.Add(this.availabilityLabel);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.slotTimeLabel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.slotDateLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.patientIdLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.slotIdLabel);
            this.Controls.Add(this.label1);
            this.Name = "AvailUnavailSlot";
            this.Text = "AvailUnavailSlot";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AvailUnavailSlot_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label slotIdLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label patientIdLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label slotDateLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label slotTimeLabel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label availabilityLabel;
        private System.Windows.Forms.Button makeUnavailableBtn;
    }
}