﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using Repository;

namespace Forms
{
    public partial class BedRenting : UserControl
    {
        Form f;
        UserControl u;
        Patient p;
        Button rentBtn, enterPatientBtn, prepareBillBtn;
        List<Bed> list;

        string query;

        public BedRenting(Form f,UserControl u,Patient p,Button rentBtn,Button enterPatientBtn,Button prepareBillBtn)
        {
            InitializeComponent();
            this.f = f;
            this.u = u;
            this.rentBtn = rentBtn;
            this.enterPatientBtn = enterPatientBtn;
            this.prepareBillBtn = prepareBillBtn;
            this.list = new List<Bed>();

            this.patientNameLabel.Text = p.Name;
            this.label3.Text = p.Name;

            this.p = p;

            refresh();
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            f.Controls.Add(u);
            f.Controls.Remove(this);

            this.enterPatientBtn.Enabled = true;
            this.prepareBillBtn.Enabled = true;
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                List<Bed> availableList = list.FindAll(x => x.Availability.Equals("true"));
                dataGridView1.DataSource = availableList;
                if (textBox3.Text.Count() != 0)
                {
                    dataGridView1.DataSource = availableList.FindAll(x => x.RoomNo.Equals(textBox3.Text));
                }
            }
            else
            {
                dataGridView1.DataSource = list;
                if (textBox3.Text.Count() != 0)
                {
                    dataGridView1.DataSource = list.FindAll(x => x.RoomNo.Equals(textBox3.Text));
                }
            }
        }

        private void thisRentBtn_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection dgv = this.dataGridView1.SelectedRows;

            if (dgv.Count != 1)
            {
                MessageBox.Show("Please select one bed");

            }
            else
            {
                string bedId = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                if (this.dataGridView1.CurrentRow.Cells[4].Value.ToString() == "true")
                {
                    DialogResult dialogResult = MessageBox.Show("Are you sure to proceed?", "Confirmation", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        p.BedNo = bedId;
                        p.Credit += Convert.ToDouble(this.dataGridView1.CurrentRow.Cells[3].Value);
                        PatientRepo pr = new PatientRepo();

                        bool updated = pr.UpdatePatient(p);
                        if (updated)
                        {
                            MessageBox.Show(bedId + " bed has been rented to " + p.Id);
                            Bed b = new Bed();
                            b.Id = bedId;
                            b.BedNo = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                            b.RoomNo = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
                            b.Rent = Convert.ToDouble(this.dataGridView1.CurrentRow.Cells[3].Value);
                            b.Availability = "false";

                            BedRepo br = new BedRepo();
                            br.UpdateBed(b);

                            Bill bl = new Bill();
                            bl.PatientId = p.Id;
                            bl.SlotId = "";
                            bl.BedId = b.Id;
                            bl.Rent = b.Rent+"";
                            bl.RentingDate = DateTime.Now+"";
                            bl.MedName = "";
                            bl.Price = "";
                            bl.Quantity = "";
                            bl.Fee = "";

                            BillRepo bir = new BillRepo();
                            bir.InsertBill(bl);

                            f.Controls.Add(u);
                            f.Controls.Remove(this);
                            this.enterPatientBtn.Enabled = true;
                            this.prepareBillBtn.Enabled = true;
                        }
                        else
                        {
                            MessageBox.Show("Operation is not successfull");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Selected Bed is not available");
                }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            this.dataGridView1.CurrentRow.Selected = true;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            checkBox1_CheckedChanged(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure to cancel the rent?", "Confirmation", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                BedRepo br = new BedRepo();
                Bed b = br.GetBed("SELECT * FROM Beds WHERE Id=" + p.BedNo);
                b.Availability = "true";
                p.BedNo = "0";
                br.UpdateBed(b);

                PatientRepo pr = new PatientRepo();
                pr.UpdatePatient(p);

                MessageBox.Show("Operation Successfull");

                refresh();
            }
            else if (dialogResult == DialogResult.No)
            {
                //do something else
            }
        }

        void refresh()
        {
            PatientRepo pr = new PatientRepo();
            this.p = pr.GetPatient("SELECT * FROM Patients WHERE Id=" + this.p.Id);

            if (p.BedNo != "0")
            {
                this.label1.Visible = false;
                this.patientNameLabel.Visible = false;
                this.dataGridView1.Visible = false;
                this.checkBox1.Visible = false;
                this.cancelBtn.Visible = false;
                this.rent.Visible = false;
                this.textBox3.Visible = false;
                this.label4.Visible = false;

                this.button1.Visible = true;
                this.button2.Visible = true;
                this.label2.Visible = true;
                this.label3.Visible = true;
                this.label5.Visible = true;

                this.button1.Text = "Bed ID:" + p.BedNo;
            }
            else
            {
                this.label1.Visible = true;
                this.patientNameLabel.Visible = true;
                this.dataGridView1.Visible = true;
                this.checkBox1.Visible = true;
                this.cancelBtn.Visible = true;
                this.rent.Visible = true;
                this.textBox3.Visible = true;
                this.label4.Visible = true;

                this.button1.Visible = false;
                this.button2.Visible = false;
                this.label2.Visible = false;
                this.label3.Visible = false;
                this.label5.Visible = false;

                query = "SELECT * FROM Beds";
                BedRepo br = new BedRepo();

                list = br.GetBedList(query);

                dataGridView1.DataSource = list;
            }
        }

    }
}
