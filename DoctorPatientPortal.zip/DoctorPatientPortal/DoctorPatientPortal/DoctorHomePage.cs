﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using Repository;

namespace Forms
{
    public partial class DoctorHomePage : Form
    {
        ManageSlot manageSlot;
        SelectCreateSlotDate selectCreateSlotDate;
        PatientMedicalHistory patientMedicalHistory;
        Entity.LogIn l;
        Doctor d;
        
        public DoctorHomePage(Entity.LogIn l)
        {
            InitializeComponent();

            this.ptntMHbtn.BackColor = Color.Silver;
            this.manageSlotBtn.BackColor = Color.DimGray;
            this.createSlotBtn.BackColor = Color.Silver;
            this.l = l;
            this.d = getDoctor();

            this.manageSlot = new ManageSlot(this,d);
            manageSlot.Location = new Point(281, 150);
            this.Controls.Add(manageSlot);
            this.manageSlotBtn.Enabled = false;
            this.doctorName.Text = d.Name;

            this.Controls.Remove(selectCreateSlotDate);
        }

        private void manageSlotBtn_Click(object sender, EventArgs e)
        {
            this.ptntMHbtn.BackColor=Color.Silver;
            this.manageSlotBtn.BackColor = Color.DimGray;
            this.createSlotBtn.BackColor = Color.Silver;

            this.manageSlot = new ManageSlot(this,d);
            manageSlot.Location = new Point(281, 150);
            this.Controls.Add(manageSlot);
            this.createSlotBtn.Enabled = true;
            this.ptntMHbtn.Enabled = true;
            this.manageSlotBtn.Enabled = false;
            if(selectCreateSlotDate!=null)
                this.Controls.Remove(selectCreateSlotDate);
            if (patientMedicalHistory != null)
                this.Controls.Remove(patientMedicalHistory);
        }

        private void createSlotBtn_Click(object sender, EventArgs e)
        {
            this.ptntMHbtn.BackColor = Color.Silver;
            this.createSlotBtn.BackColor = Color.DimGray;
            this.manageSlotBtn.BackColor = Color.Silver;

            this.createSlotBtn.Enabled = false;
            this.ptntMHbtn.Enabled = true;
            this.manageSlotBtn.Enabled = true;
            
            selectCreateSlotDate = new SelectCreateSlotDate(d,this,this.manageSlotBtn,this.ptntMHbtn,this.createSlotBtn);
            selectCreateSlotDate.Location = new Point(281, 150);
            
            this.Controls.Add(selectCreateSlotDate);
            if(manageSlot!=null)
                this.Controls.Remove(manageSlot);
            if (patientMedicalHistory != null)
                this.Controls.Remove(patientMedicalHistory);
        }

        private void ptntMHbtn_Click(object sender, EventArgs e)
        {
            this.ptntMHbtn.BackColor = Color.DimGray;
            this.createSlotBtn.BackColor = Color.Silver;
            this.manageSlotBtn.BackColor = Color.Silver;

            this.createSlotBtn.Enabled = true;
            this.ptntMHbtn.Enabled = false;
            this.manageSlotBtn.Enabled = true;

            patientMedicalHistory = new PatientMedicalHistory(this);
            patientMedicalHistory.Location = new Point(281, 150);

            this.Controls.Add(patientMedicalHistory);
            if (manageSlot != null)
                this.Controls.Remove(manageSlot);
            if (selectCreateSlotDate != null)
                this.Controls.Remove(selectCreateSlotDate);
        }

        public Doctor getDoctor()
        {
            DoctorRepo dr = new DoctorRepo();
            string query="SELECT * FROM Doctors WHERE Id="+l.Id;
            Doctor d=dr.GetDoctor(query);
            return d;
        }

        private void OnFormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void logOut_Click(object sender, EventArgs e)
        {
            this.Dispose();
            WelcomeForm f = new WelcomeForm();
            f.Visible = true;
            
        }

        private void doctorProfile_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            DoctorProfile df = new DoctorProfile(d,this,l);
            df.Visible = true; 
        }
    }
}
