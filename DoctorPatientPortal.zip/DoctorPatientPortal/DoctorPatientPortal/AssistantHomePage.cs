﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using Repository;

namespace Forms
{
    public partial class AssistantHomePage : Form
    {
        Entity.LogIn l;
        EnterNewPatient enp;
        UpdatePatient up;
        Assistant a;
        SelectPatient sp;

        public AssistantHomePage(Entity.LogIn l)
        {
            InitializeComponent();

            this.l = l;

            this.enterPatientBtn.BackColor = Color.DimGray;
            this.updatePatientBtn.BackColor = Color.Silver;
            this.bookCancelBtn.BackColor = Color.Silver;

            enp = new EnterNewPatient();
            enp.Location = new Point(281, 150);
            this.Controls.Add(enp);

            a = getAssistant();
            this.assistantName.Text = a.Name;
        }

        private void enterPatientBtn_Click(object sender, EventArgs e)
        {
            this.enterPatientBtn.BackColor = Color.DimGray;
            this.updatePatientBtn.BackColor = Color.Silver;
            this.bookCancelBtn.BackColor = Color.Silver;

            enp = new EnterNewPatient();
            enp.Location = new Point(281, 150);
            this.Controls.Add(enp);
            if(sp!=null)
                this.Controls.Remove(sp);
            if (up != null)
                this.Controls.Remove(up);

            this.enterPatientBtn.Enabled = false;
            this.updatePatientBtn.Enabled = true;
            this.bookCancelBtn.Enabled = true;
        }

        private Assistant getAssistant()
        {
            AssistantRepo ar = new AssistantRepo();
            string query = "SELECT * FROM Assistants WHERE Id=" + l.Id;

            return ar.GetAssistant(query);
        }

        private void bookCancelBtn_Click(object sender, EventArgs e)
        {
            this.enterPatientBtn.Enabled = true;
            this.enterPatientBtn.BackColor = Color.Silver;
            this.updatePatientBtn.Enabled = true;
            this.updatePatientBtn.BackColor = Color.Silver;
            this.bookCancelBtn.Enabled = false;
            this.bookCancelBtn.BackColor = Color.DimGray;

            sp = new SelectPatient(this, enterPatientBtn, updatePatientBtn, bookCancelBtn);
            sp.Location = new Point(281, 150);

            this.Controls.Add(sp);
            if (enp != null) 
                this.Controls.Remove(enp);
            if (up != null)
                this.Controls.Remove(up);
        }

        private void assistantProfile_Click(object sender, EventArgs e)
        {
            AssistantProfile ap = new AssistantProfile(a, this,l);
            this.Enabled = false;
            ap.Visible = true;
        }

        private void logOut_Click(object sender, EventArgs e)
        {
            this.Dispose();
            WelcomeForm f = new WelcomeForm();
            f.Visible = true;
        }

        private void updatePatientBtn_Click(object sender, EventArgs e)
        {
            this.enterPatientBtn.BackColor = Color.Silver;
            this.enterPatientBtn.Enabled = true;
            this.updatePatientBtn.BackColor = Color.DimGray;
            this.updatePatientBtn.Enabled = false;
            this.bookCancelBtn.BackColor = Color.Silver;
            this.bookCancelBtn.Enabled = true;

            this.up = new UpdatePatient(this);
            up.Location = new Point(281, 150);
            this.Controls.Add(up);
            if(sp!=null)
                this.Controls.Remove(sp);
            if(enp!=null)
                this.Controls.Remove(enp);
        }

        private void AssistantHomePage_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
