﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using Repository;

namespace Forms
{
    public partial class BookCancelSlot : UserControl
    {
        Form f;
        UserControl u;
        Patient p;
        Button b1, b2, b3;

        public BookCancelSlot(Form f,UserControl u,Patient p,Button b1,Button b2, Button b3)
        {
            InitializeComponent();
            this.f = f;
            this.u = u;
            this.p = p;
            this.b1 = b1;
            this.b2 = b2;
            this.b3 = b3;
            this.label1.Text = this.label1.Text + p.Id;

            refresh();
        }

        void refresh()
        {
            SlotRepo sr = new SlotRepo();
            Slot s = sr.GetSlot("SELECT * FROM Slots WHERE PatientId=" + p.Id);
            if (s != null)
            {
                DateTime dt1 = DateTime.Parse(s.SlotDate);
                DateTime dt2 = DateTime.Now;

                if (dt1.AddDays(1) <= dt2)
                {
                    s.PatientId = "0";
                    sr.UpdateSlot(s);

                    slotBtn.Visible = false;
                    label2.Visible = false;
                    label3.Visible = true;
                    bookBtn.Visible = true; 
                }
                else
                {
                    slotBtn.Text = "ID: " + s.Id + "\nDoctor:" + s.DoctorId + "\nTime: " + s.SlotTime + "\nDate: " + s.SlotDate;
                    slotBtn.Visible = true;
                    label2.Visible = true;
                    label3.Visible = false;
                    bookBtn.Visible = false;

                    if (s.Availability.Equals("true"))
                    {
                        slotBtn.BackColor = Color.Green;
                    }
                    else
                    {
                        slotBtn.BackColor = Color.Red;
                    }
                }
            }
            else
            {
                slotBtn.Visible = false;
                label2.Visible = false;
                label3.Visible = true;
                bookBtn.Visible = true;                
            }
        }

        private void bookBtn_Click(object sender, EventArgs e)
        {
            BookSlot bs = new BookSlot(f, p, u,b1,b2,b3);
            bs.Location = new Point(281, 150);
            f.Controls.Add(bs);
            f.Controls.Remove(this);
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            f.Controls.Add(u);
            f.Controls.Remove(this);
            b1.Enabled = true;
            b2.Enabled = true;
        }

        private void slotBtn_Click(object sender, EventArgs e)
        {


            DialogResult dialogResult = MessageBox.Show("Are you sure to cancel the slot?", "Confirmation", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                SlotRepo sr = new SlotRepo();
                Slot s = sr.GetSlot("SELECT * FROM Slots WHERE PatientId=" + p.Id);
                s.PatientId = "0";
                s.Availability = "true";
                sr.UpdateSlot(s);

                Bill b = new Bill();
                b.PatientId = p.Id;

                BillRepo br = new BillRepo();
                br.DeleteBill(b, s.Id);

                PatientRepo pr = new PatientRepo();
                string query = "SELECT * FROM Patients WHERE Id=" + p.Id;
                p = pr.GetPatient(query);
                p.Credit = p.Credit - s.Price;
                pr.UpdatePatient(p);

                MessageBox.Show("Slot Cancelled Succesfully");
                backBtn_Click(sender, e);
            }
            else if (dialogResult == DialogResult.No)
            {
                //do something else
            }
        }
    }
}
