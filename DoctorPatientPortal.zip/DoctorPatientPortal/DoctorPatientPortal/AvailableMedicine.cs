﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repository;
using Entity;

namespace Forms
{
    public partial class AvailableMedicine : UserControl
    {
        DrugRepo dr = new DrugRepo();
        RequestedMedRepo rmr = new RequestedMedRepo();
        List<Drug> list;
        List<RequestedMed> rList;

        public AvailableMedicine()
        {
            InitializeComponent();

            list = new List<Drug>();
            list = dr.GetDrugList("SELECT * FROM Drugs WHERE AvailableQuantity>0");

            dataGridView1.DataSource = list;

            rList = new List<RequestedMed>();
            rList = rmr.GetRequestedMedList("SELECT * FROM RequestedMeds");

            dataGridView2.DataSource = rList;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            list = new List<Drug>();
            list = dr.GetDrugList("SELECT * FROM Drugs WHERE AvailableQuantity>0");

            string keyword = searchBox.Text;

            if(keyword.Length==0)
            {
                dataGridView1.DataSource = list;
            }
            else
            {
                List<Drug> searchedList = list.FindAll(X => (X.Name.ToLower()).Contains(keyword.ToLower()));
                dataGridView1.DataSource = searchedList;
            }
        }

        private void requestBtn_Click(object sender, EventArgs e)
        {
            try
            {
                double q = Convert.ToDouble(quantityTB.Text);
                if (nameTB.Text.Count() != 0)
                {
                    DialogResult dialogResult = MessageBox.Show("Are you sure to place this request?", "Confirmation", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        RequestedMed rm = new RequestedMed();
                        rm.Name = nameTB.Text.ToUpper();
                        rm.Quantity = q;
                        bool inserted = rmr.InsertRequestedMed(rm);
                        if (inserted)
                        {
                            MessageBox.Show("Successfully Requested");
                            rList = rmr.GetRequestedMedList("SELECT * FROM RequestedMeds");
                            dataGridView2.DataSource = rList;
                            nameTB.Text = "";
                            quantityTB.Text = "";
                        }
                        else
                        {
                            MessageBox.Show("Operation Failed");
                        }
                    }
                    else if (dialogResult == DialogResult.No)
                    {
                        //do something else
                    }
                    
                }
                else
                {
                    MessageBox.Show("Invalid Input");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Invalid Quantity");
            }
        }
    }
}
