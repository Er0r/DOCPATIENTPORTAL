﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repository;
using Entity;

namespace Forms
{
    public partial class BookSlot : UserControl
    {
        List<Button> buttonList;
        SlotRepo sr;
        UserControl u;
        Button b1, b2, b3;
        Form f;
        Patient p;

        public BookSlot(Form f,Patient p,UserControl u,Button b1,Button b2,Button b3)
        {
            InitializeComponent();

            this.u = u;
            this.f = f;
            this.p = p;
            this.b1 = b1;
            this.b2 = b2;
            this.b3 = b3;

            buttonList = new List<Button>();
            sr = new SlotRepo();

            DoctorRepo dr = new DoctorRepo();
            List<Doctor> dList = dr.GetDoctorList("SELECT * FROM Doctors");

            comboBox1.DataSource = dList;
            comboBox1.DisplayMember = "Name";
            comboBox1.ValueMember = "Id";
            
            comboBox1.SelectedValue = dList.ElementAt(0).Id;

            Console.WriteLine("kkkkkkkkkkkkkkkk"+comboBox1.SelectedValue);

            buttonList.Add(button1);
            buttonList.Add(button2);
            buttonList.Add(button3);
            buttonList.Add(button4);
            buttonList.Add(button5);
            buttonList.Add(button6);
            buttonList.Add(button7);
            buttonList.Add(button8);
            buttonList.Add(button9);
            buttonList.Add(button10);
            buttonList.Add(button11);
            buttonList.Add(button12);
            buttonList.Add(button13);
            buttonList.Add(button14);
            buttonList.Add(button15);
            buttonList.Add(button16);
            buttonList.Add(button17);
            buttonList.Add(button18);
            buttonList.Add(button19);
            buttonList.Add(button20);
            buttonList.Add(button21);
            buttonList.Add(button22);
            buttonList.Add(button23);
            buttonList.Add(button24);
            buttonList.Add(button25);

            HideSlots();
            this.dateTimePicker1.Text = "";
        }

        public void ShowSlots()
        {
            HideSlots();
            List<Slot> slotList = new List<Slot>();

            string docId = null;
            docId=this.comboBox1.SelectedValue.ToString();
            string date=this.dateTimePicker1.Text;
            Console.WriteLine("date:"+date);
            string query = "SELECT * from Slots where SlotDate='" + date + "' and Availability='true' and DoctorId='"+docId+"'";
            slotList = sr.GetSlotList(query);
            if (slotList.Count != 0)
            {
                for (int i = 0; i < slotList.Count; i++)
                {
                    buttonList.ElementAt(i).Text =  slotList.ElementAt(i).SlotTime;
                    buttonList.ElementAt(i).Tag = slotList.ElementAt(i).Id;
                    buttonList.ElementAt(i).Visible = true;
                    buttonList.ElementAt(i).BackColor = Color.Green;
                }
                label2.Visible = false;
            }
            else
            {
                label2.Visible = true;
            }

        }

        public void HideSlots()
        {
            foreach (Button b in buttonList) 
            {
                b.Visible = false;
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            ShowSlots();  
        }

        private void OnLoad(object sender, EventArgs e)
        {
            this.dateTimePicker1_ValueChanged(sender, e);
            this.comboBox1_SelectedValueChanged(sender, e);
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            BookCancelSlot bcs = new BookCancelSlot(f, u, p, b1, b2, b2);
            bcs.Location = new Point(281,150);
            f.Controls.Add(bcs);
            f.Controls.Remove(this);
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            ShowSlots();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button24_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button19_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button22_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button17_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button21_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        private void button25_Click(object sender, EventArgs e)
        {
            book(sender, e);
        }

        void book(object sender, EventArgs e)
        {
            SlotRepo sr = new SlotRepo();
            Button btn = (Button)sender;

            DialogResult dialogResult = MessageBox.Show("Are you sure to book this slot?", "Confirmation", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                string query = "SELECT * FROM Slots WHERE Id="+btn.Tag.ToString();
                Slot s = sr.GetSlot(query);
                PatientRepo pr = new PatientRepo();
                query = "SELECT * FROM Patients WHERE Id=" + p.Id;
                p = pr.GetPatient(query);
                s.PatientId = p.Id;
                s.Availability = "false";
                p.Credit =p.Credit+s.Price;
                sr.UpdateSlot(s);
                pr.UpdatePatient(p);

                Bill b = new Bill();
                b.PatientId = p.Id;
                b.SlotId = s.Id;
                b.Fee = s.Price+"";
                b.MedName = "";
                b.Rent = "";
                b.RentingDate = "";
                b.Quantity = "";
                b.Price = "";
                b.BedId = "";

                BillRepo br = new BillRepo();
                br.InsertBill(b);

                MessageBox.Show("Slot Booked Successfully.");

                BookCancelSlot bcs = new BookCancelSlot(f, u, p, b1, b2, b2);
                bcs.Location = new Point(281, 150);
                f.Controls.Add(bcs);
                f.Controls.Remove(this);
            }
            else if (dialogResult == DialogResult.No)
            {

            }
        }
        
    }
}
