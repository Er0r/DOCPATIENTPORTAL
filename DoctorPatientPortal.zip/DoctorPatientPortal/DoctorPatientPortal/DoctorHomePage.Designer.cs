﻿namespace Forms
{
    partial class DoctorHomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.doctorName = new System.Windows.Forms.Label();
            this.doctorProfile = new System.Windows.Forms.Button();
            this.logOut = new System.Windows.Forms.Button();
            this.ptntMHbtn = new System.Windows.Forms.Button();
            this.manageSlotBtn = new System.Windows.Forms.Button();
            this.createSlotBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(71, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome back,";
            // 
            // doctorName
            // 
            this.doctorName.AutoSize = true;
            this.doctorName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doctorName.Location = new System.Drawing.Point(264, 96);
            this.doctorName.Name = "doctorName";
            this.doctorName.Size = new System.Drawing.Size(92, 31);
            this.doctorName.TabIndex = 1;
            this.doctorName.Text = "label2";
            // 
            // doctorProfile
            // 
            this.doctorProfile.Location = new System.Drawing.Point(1085, 34);
            this.doctorProfile.Name = "doctorProfile";
            this.doctorProfile.Size = new System.Drawing.Size(75, 23);
            this.doctorProfile.TabIndex = 2;
            this.doctorProfile.Text = "profile";
            this.doctorProfile.UseVisualStyleBackColor = true;
            this.doctorProfile.Click += new System.EventHandler(this.doctorProfile_Click);
            // 
            // logOut
            // 
            this.logOut.Location = new System.Drawing.Point(1188, 34);
            this.logOut.Name = "logOut";
            this.logOut.Size = new System.Drawing.Size(75, 23);
            this.logOut.TabIndex = 3;
            this.logOut.Text = "log out";
            this.logOut.UseVisualStyleBackColor = true;
            this.logOut.Click += new System.EventHandler(this.logOut_Click);
            // 
            // ptntMHbtn
            // 
            this.ptntMHbtn.BackColor = System.Drawing.Color.DimGray;
            this.ptntMHbtn.Location = new System.Drawing.Point(114, 358);
            this.ptntMHbtn.Name = "ptntMHbtn";
            this.ptntMHbtn.Size = new System.Drawing.Size(127, 68);
            this.ptntMHbtn.TabIndex = 4;
            this.ptntMHbtn.Text = "Patient\'s Medical History";
            this.ptntMHbtn.UseVisualStyleBackColor = false;
            this.ptntMHbtn.Click += new System.EventHandler(this.ptntMHbtn_Click);
            // 
            // manageSlotBtn
            // 
            this.manageSlotBtn.Location = new System.Drawing.Point(114, 218);
            this.manageSlotBtn.Name = "manageSlotBtn";
            this.manageSlotBtn.Size = new System.Drawing.Size(127, 63);
            this.manageSlotBtn.TabIndex = 5;
            this.manageSlotBtn.Text = "Manage Slot";
            this.manageSlotBtn.UseVisualStyleBackColor = true;
            this.manageSlotBtn.Click += new System.EventHandler(this.manageSlotBtn_Click);
            // 
            // createSlotBtn
            // 
            this.createSlotBtn.Location = new System.Drawing.Point(114, 497);
            this.createSlotBtn.Name = "createSlotBtn";
            this.createSlotBtn.Size = new System.Drawing.Size(127, 72);
            this.createSlotBtn.TabIndex = 6;
            this.createSlotBtn.Text = "Create Slot";
            this.createSlotBtn.UseVisualStyleBackColor = true;
            this.createSlotBtn.Click += new System.EventHandler(this.createSlotBtn_Click);
            // 
            // DoctorHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.createSlotBtn);
            this.Controls.Add(this.manageSlotBtn);
            this.Controls.Add(this.ptntMHbtn);
            this.Controls.Add(this.logOut);
            this.Controls.Add(this.doctorProfile);
            this.Controls.Add(this.doctorName);
            this.Controls.Add(this.label1);
            this.Name = "DoctorHomePage";
            this.Text = "DoctorHomePage";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.OnFormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label doctorName;
        private System.Windows.Forms.Button doctorProfile;
        private System.Windows.Forms.Button logOut;
        public System.Windows.Forms.Button ptntMHbtn;
        public System.Windows.Forms.Button manageSlotBtn;
        public System.Windows.Forms.Button createSlotBtn;
    }
}