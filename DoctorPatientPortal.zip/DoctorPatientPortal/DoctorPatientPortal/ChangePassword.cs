﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Repository;

namespace Forms
{
    public partial class ChangePassword : Form
    {
        Entity.LogIn l;

        public ChangePassword(Entity.LogIn l)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            this.l = l;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.l.Password.Equals(textBox2.Text))
            {
                if (textBox1.Text.Length < 8)
                {
                    MessageBox.Show("Password length must be at least 8");
                }
                else
                {
                    l.Password = textBox1.Text;
                    LogInRepo lr = new LogInRepo();
                    if (lr.UpdateUser(l))
                    {
                        MessageBox.Show("Password Change Successfull.");
                    }
                    else
                    {
                        MessageBox.Show("Operation Failed.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Current Password is Incorrect.");
            }
        }
    }
}
