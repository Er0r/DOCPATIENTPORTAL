﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity;
using Repository;

namespace Forms
{
    public partial class EnterNewPatient : UserControl
    {
        PatientRepo pr;

        public EnterNewPatient()
        {
            InitializeComponent();
            label6.Text = "";
            pr = new PatientRepo();
            List<Patient> list = pr.GetPatientList("SELECT * FROM Patients");
            dataGridView1.DataSource = list;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Patient p = new Patient();
            bool inserted = false;

            try
            {
                double id=Convert.ToDouble(this.idTextBox.Text);
                double age = Convert.ToDouble(this.ageTextBox.Text);
                double contact = Convert.ToDouble(this.contactTextBox.Text);

                if (nameTextBox.Text.Length != 0)
                {
                    p.Id = this.idTextBox.Text;
                    p.Name = this.nameTextBox.Text;
                    p.Age = age;
                    p.ContactNo = "+880" + this.contactTextBox.Text;

                    inserted=pr.InsertPatient(p);

                    if (inserted)
                    {
                        label6.Text="Patient Inserted Successfully with ID: "+p.Id;
                        
                        this.idTextBox.Text = "";
                        this.nameTextBox.Text = "";
                        this.ageTextBox.Text = "";
                        this.contactTextBox.Text = "";

                        List<Patient> list = pr.GetPatientList("SELECT * FROM Patients");
                        dataGridView1.DataSource = list;
                    }
                    else
                    {
                        MessageBox.Show("Invalid ID.");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Input'");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Invalid Input'");
            }
        }

        private void serachTb_TextChanged(object sender, EventArgs e)
        {
            List<Patient> list = pr.GetPatientList("SELECT * FROM Patients");
            dataGridView1.DataSource = list;

            string keyword = searchTb.Text;

            if (keyword.Length == 0)
            {
                dataGridView1.DataSource = list;
            }
            else
            {
                List<Patient> searchedList = list.FindAll(X => (X.Name.ToLower()).Contains(keyword.ToLower()));
                dataGridView1.DataSource = searchedList;
            }
        }
    }
}
